let arr = [1, 2, 3, 4];

for (const ar of arr) {
  console.log(ar);
}
